$(document).on('ready', function() {
    "use strict";
    $("#navigation").menumaker({
        title: "Menu",
        format: "multitoggle"
    });
});