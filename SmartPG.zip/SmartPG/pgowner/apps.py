from django.apps import AppConfig


class PgownerConfig(AppConfig):
    name = 'pgowner'
