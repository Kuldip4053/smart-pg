from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(user)
admin.site.register(area)
admin.site.register(pgdetails)
admin.site.register(pgowner)
admin.site.register(bookingdetails)
admin.site.register(pgtype)
admin.site.register(feedback)
admin.site.register(wishlist)
admin.site.register(inquiry)
admin.site.register(pgfacility)
admin.site.register(WeekMenu)

